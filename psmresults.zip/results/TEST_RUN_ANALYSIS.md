## What Worked ✅

**Static Analysis Phase:**
- API extraction: 2 APIs identified correctly
  - `parse_int_list(const char* s, size_t n) → int`
  - `compute_average(const int* values, size_t count, double* out_avg) → int`
- Headers detected: `intlist.h`, `stats.h`
- Sequence generation: 18 raw sequences → 1 filtered (94.4% reduction)
- Docker image build: successful

## Errors & Failures ❌

### Trial 1: parse_int_list
**Error:** Compilation failed - missing header
```c
#include "test-project/parser.h"  // ❌ File not found
fatal error: 'test-project/parser.h' file not found
```
**Reason:** LLM hallucinated include path. Correct path: `#include "intlist.h"`

### Trial 2: compute_average
**Error:** Compilation failed - two issues
```c
char *s = (void*)data;          // ❌ Invalid C++ cast (should be (char*)data)
parse_int_list(s, n);           // ❌ Undeclared - no #include "intlist.h"
```
**Reasons:** 
1. Invalid void pointer cast in C++ context
2. Missing #include directive for referenced function
3. Called wrong function (parse_int_list instead of compute_average target)

## Root Causes

| Issue | Reason |
|-------|--------|
| Trial 1: `test-project/parser.h` | LLM inferred nested path from `target_path: /src/test-project/fuzzer.c` but doesn't exist. Should use `#include "intlist.h"` with `-Iinclude` flag. |
| Trial 2: `(void*)data` invalid cast | LLM generated C-style cast but code compiled as C++ (`.cpp`), requiring explicit `(char*)` cast. |
| Trial 2: `parse_int_list()` undeclared | LLM never added `#include "intlist.h"` before calling the function. |
| Trial 2: Called wrong function | LLM followed grammar sequence suggestion but lost semantic context that `compute_average()` was the target. |

**Summary:** LLM lacked (1) function→header mapping, (2) build script context, (3) awareness that `.c` → `.cpp` triggers C++ compilation, and (4) proper anchoring to target function in function-level mode.
